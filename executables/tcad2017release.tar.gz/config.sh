#########################################################################
# File Name: config.sh
# Author: Yibo Lin
# mail: yibolin@utexas.edu
# Created Time: Wed 03 Feb 2016 11:15:03 AM CST
#########################################################################
#!/bin/bash

# use a map to save target utilities
declare -A util_map
# use a map to save max displacement
declare -A max_displace_map
# iccad 2014
util_map["iccad2014-b19"]=0.76
util_map["iccad2014-vga_lcd"]=0.7
util_map["iccad2014-leon2"]=0.7
util_map["iccad2014-leon3mp"]=0.7
util_map["iccad2014-netcard"]=0.72
util_map["iccad2014-mgc_edit_dist"]=0.75
util_map["iccad2014-mgc_matrix_mult"]=0.65
util_map["iccad2014-simple"]=0.7
# iccad 2014 
max_displace_map["iccad2014-b19"]=20 #50
max_displace_map["iccad2014-vga_lcd"]=20 #50
max_displace_map["iccad2014-leon2"]=40 #100
max_displace_map["iccad2014-leon3mp"]=30 #75
max_displace_map["iccad2014-netcard"]=50 #125
max_displace_map["iccad2014-mgc_edit_dist"]=30 # 200 
max_displace_map["iccad2014-mgc_matrix_mult"]=30 # 200
max_displace_map["iccad2014-simple"]=10

# iccad 2015 
util_map["iccad2015-superblue18"]=0.85
util_map["iccad2015-superblue16"]=0.85
util_map["iccad2015-superblue4"]=0.9
util_map["iccad2015-superblue10"]=0.87
util_map["iccad2015-superblue7"]=0.90
util_map["iccad2015-superblue1"]=0.80
util_map["iccad2015-superblue3"]=0.87
util_map["iccad2015-superblue5"]=0.85
# iccad 2015
max_displace_map["iccad2015-superblue18"]=20 #400
max_displace_map["iccad2015-superblue16"]=30 #400
max_displace_map["iccad2015-superblue4"]=20 #400
max_displace_map["iccad2015-superblue10"]=20 #500
max_displace_map["iccad2015-superblue7"]=50 #500
max_displace_map["iccad2015-superblue1"]=40 #400
max_displace_map["iccad2015-superblue3"]=40 #400
max_displace_map["iccad2015-superblue5"]=40 #400

# bookshelf 
util_map["bookshelf-simple"]=1.0
util_map["bookshelf-acc64"]=0.8
util_map["bookshelf-adaptec1_dr"]=0.91
util_map["bookshelf-adaptec2_dr"]=0.90
util_map["bookshelf-adaptec3_dr"]=0.80
util_map["bookshelf-adaptec4_dr"]=0.75
util_map["bookshelf-bigblue1_dr"]=0.80
util_map["bookshelf-bigblue2_dr"]=0.75
util_map["bookshelf-bigblue3_dr"]=0.91
util_map["bookshelf-bigblue4_dr"]=0.75
# bookshelf
max_displace_map["bookshelf-simple"]=100
max_displace_map["bookshelf-acc64"]=60
max_displace_map["bookshelf-adaptec1_dr"]=20
max_displace_map["bookshelf-adaptec2_dr"]=20
max_displace_map["bookshelf-adaptec3_dr"]=20
max_displace_map["bookshelf-adaptec4_dr"]=20
max_displace_map["bookshelf-bigblue1_dr"]=20
max_displace_map["bookshelf-bigblue2_dr"]=20
max_displace_map["bookshelf-bigblue3_dr"]=30
max_displace_map["bookshelf-bigblue4_dr"]=30

# ispd 2015 
util_map["ispd2015-mgc_des_perf_1"]=0.906
util_map["ispd2015-mgc_des_perf_a"]=0.429
util_map["ispd2015-mgc_des_perf_b"]=0.497
util_map["ispd2015-mgc_edit_dist_a"]=0.455
util_map["ispd2015-mgc_fft_1"]=0.835
util_map["ispd2015-mgc_fft_2"]=0.65
util_map["ispd2015-mgc_fft_a"]=0.5
util_map["ispd2015-mgc_fft_b"]=0.6
util_map["ispd2015-mgc_matrix_mult_1"]=0.802
util_map["ispd2015-mgc_matrix_mult_a"]=0.6
util_map["ispd2015-mgc_matrix_mult_b"]=0.6
util_map["ispd2015-mgc_pci_bridge32_a"]=0.384
util_map["ispd2015-mgc_pci_bridge32_b"]=0.143
util_map["ispd2015-mgc_superblue11_a"]=0.65
util_map["ispd2015-mgc_superblue12"]=0.65
util_map["ispd2015-mgc_superblue16_a"]=0.55
# ispd2015 hidden 
util_map["ispd2015-mgc_matrix_mult_2"]=0.8
util_map["ispd2015-mgc_matrix_mult_c"]=0.6
util_map["ispd2015-mgc_superblue14"]=0.56
util_map["ispd2015-mgc_superblue19"]=0.53
# ispd 2015 
max_displace_map["ispd2015-mgc_des_perf_1"]=30
max_displace_map["ispd2015-mgc_des_perf_a"]=20
max_displace_map["ispd2015-mgc_des_perf_b"]=30
max_displace_map["ispd2015-mgc_edit_dist_a"]=30
max_displace_map["ispd2015-mgc_fft_1"]=30
max_displace_map["ispd2015-mgc_fft_2"]=30
max_displace_map["ispd2015-mgc_fft_a"]=30
max_displace_map["ispd2015-mgc_fft_b"]=30
max_displace_map["ispd2015-mgc_matrix_mult_1"]=30
max_displace_map["ispd2015-mgc_matrix_mult_a"]=30
max_displace_map["ispd2015-mgc_matrix_mult_b"]=30
max_displace_map["ispd2015-mgc_pci_bridge32_a"]=30
max_displace_map["ispd2015-mgc_pci_bridge32_b"]=30
max_displace_map["ispd2015-mgc_superblue11_a"]=300
max_displace_map["ispd2015-mgc_superblue12"]=200
max_displace_map["ispd2015-mgc_superblue16_a"]=30
# ispd2015 hidden 
max_displace_map["ispd2015-mgc_matrix_mult_2"]=30
max_displace_map["ispd2015-mgc_matrix_mult_c"]=30
max_displace_map["ispd2015-mgc_superblue14"]=30
max_displace_map["ispd2015-mgc_superblue19"]=300

# key commands to tune the program 
options="\
	--abu 2,10 \
	--abu 5,4 \
	--abu 10,2 \
	--abu 20,1 \
    --enable_legalize true \
    --legalize_actions RowPlace,solverType=MCF_DISP,numRows=18,multiRowMovableStrategy=0 \
    --legalize_actions GlobalMove \
    --legalize_rest_action GlobalMove \
    --enable_place true \
    --place_actions GlobalMove,algoType=GLOBALMOVECHAIN \
    --place_actions GlobalMove,algoType=GLOBALMOVE \
    --place_actions RowPlace,solverType=MCF_WL,numRows=18,considerBinDensity=true,densityThresholdRatio=0.95 \
    --place_actions GlobalMove,algoType=GLOBALMOVECHAIN,effort=DENSITY,shuffleOrdering=3,estimatePinDensity=false \
    --max_iters 6 \
    --evaluate_overlap true \
    --move_multi_row_cell true \
    --align_power_line true \
    --cluster_cell true \
    --draw_place_init false \
    --draw_place_final false \
    "
