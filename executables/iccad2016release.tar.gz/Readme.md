# GPF #
--------------

A generic framework for VLSI placement. 

--------------
## Authors & Maintainers 

| Name                               | Affiliation                 | Email                           |
| ---------------------------------- | --------------------------- | ------------------------------- |
| [Yibo Lin](http://www.yibolin.com) | ECE Dept, UT Austin         | yibolin@utexas.edu              |

--------------
## Publications 

* Yibo Lin, Bei Yu, Xiaoqing Xu, Jhih-Rong Gao, Natarajan Viswanathan, Wen-Hao Liu, Zhuo Li, Charles J Alpert and David Z. Pan, 
  "MrDP: Multiple-row detailed placement of heterogeneous-sized cells for advanced nodes", 
  IEEE/ACM International Conference on Computer-Aided Design (ICCAD), Austin, TX, Nov 7-10, 2016

--------------
## External Dependencies 

### 1. [Boost](http://www.boost.org)

Version 1.55.0

### 2. Limbo 

A VLSI physical design library developed by [Yibo Lin](http://www.yibolin.com)

--------------
## Installation 

### 1. Debug mode 

```
cd src 
make -j DBG=1 
```

### 2. Release mode 

```
cd src
make -j DBG=0 (default)
```

### 3. GNU profiling mode 

```
cd src 
make -j GPROF=1
```

--------------
## Execution 

```
bin/gpf --help          # see help message
source run_iccad2014.sh # run ICCAD 2014 benchmarks 
source run_isu.sh       # run ISPD 2004 benchmarks from ISU 
```
The script of run_iccad2014.sh assumes an environment variable BENCHMARKS_DIR is defined and the benchmarks are under $BENCHMARKS_DIR/iccad2014. 
The script of run_isu.sh assumes the benchmarks are under $BENCHMARKS_DIR/drdp_utexas/benchmarks. 
Modify the scripts if your benchmarks have different directories. 

