#########################################################################
# File Name: run_isu.sh
# Author: Yibo Lin
# mail: yibolin@utexas.edu
# Created Time: Wed 16 Mar 2016 01:28:23 AM CDT
#########################################################################
#!/bin/bash

benchmarks_dir="$BENCHMARKS_DIR/drdp_utexas/benchmarks"
benchmark_map=(\
"adaptec1_dr" \
"adaptec2_dr" \
"adaptec3_dr" \
"adaptec4_dr" \
"bigblue1_dr" \
"bigblue2_dr" \
"bigblue3_dr" \
"bigblue4_dr" \
)

# config environment 
source config.sh
# create directory for solution 
solution_dir="./sol_isu"
mkdir -p ${solution_dir}

############### detail placement ################
suffix="" # empty or .ref or .ref2 

for benchmark in "${benchmark_map[@]}"; do 

if [[ $suffix == ".ref2" ]]; then 
    bookshelf_pl_input="$BENCHMARKS_DIR/drdp_utexas/${benchmark}/${benchmark}_DRDP_res.pl"
else 
    bookshelf_pl_input="${benchmarks_dir}/${benchmark}/${benchmark}_GP_res"
fi

commands="\
    -config NORMAL \
    --bookshelf_aux_input ${benchmarks_dir}/${benchmark}/${benchmark}.mr.aux \
    --bookshelf_pl_input ${bookshelf_pl_input} \
	--target_util ${util_map[bookshelf-$benchmark]} \
	--max_displace ${max_displace_map[bookshelf-$benchmark]} \
    --file_format Bookshelf \
	--def_output ${solution_dir}/${benchmark}-out.pl \
    --rpt_output rpt_isu/${benchmark}${suffix}.html \
    ${options} \
    "
echo "bin/MrDP $commands"
# run placement 
time ("bin/MrDP" $commands) > rpt_isu/${benchmark}${suffix}.rpt 2>&1

echo "run evaluation and append to rpt_isu/${benchmark}${suffix}.rpt"
# run evaluation and append to .rpt 
./lib/iccad2013_check_legality/iccad2013_check_legality \
    ${benchmarks_dir}/${benchmark}/${benchmark}.mr.aux \
    ${solution_dir}/${benchmark}-out.pl \
    >> rpt_isu/${benchmark}${suffix}.rpt

./lib/iccad2013_evaluate_solution/iccad2013_evaluate_solution \
    ${benchmarks_dir}/${benchmark}/${benchmark}.mr.aux \
    ${solution_dir}/${benchmark}-out.pl \
    ${util_map[bookshelf-$benchmark]} \
    >> rpt_isu/${benchmark}${suffix}.rpt
	
done
