#########################################################################
# File Name: run_iccad2014.sh
# Author: Yibo Lin
# mail: yibolin@utexas.edu
# Created Time: Mon 18 Apr 2016 12:03:36 AM CDT
#########################################################################
#!/bin/bash

year=2014 # must be 2014 here 
mrsuffix=".mr" # .mr or empty, only valid with NORMAL configuration
benchmarks_dir="$BENCHMARKS_DIR/iccad${year}"
benchmark_map=(\
"vga_lcd" \
"b19" \
"leon3mp" \
"leon2" \
"mgc_edit_dist" \
"mgc_matrix_mult" \
"netcard" \
)
# config environment 
source config.sh
# create directory for solution 
solution_dir="./sol_iccad2014"
mkdir -p ${solution_dir}

############### detail placement ################
suffix="" # empty or .ref or .ref2

for benchmark in "${benchmark_map[@]}"; do 

commands="\
    -config NORMAL \
    --lef_input ${benchmarks_dir}/${benchmark}/techlib${mrsuffix}.lef \
	--def_input ${benchmarks_dir}/${benchmark}/${benchmark}${mrsuffix}.def \
    --verilog_input ${benchmarks_dir}/${benchmark}/${benchmark}.v \
	--target_util ${util_map[iccad${year}-$benchmark]} \
	--max_displace ${max_displace_map[iccad${year}-$benchmark]} \
    --file_format Bookshelf \
	--def_output ${solution_dir}/${benchmark}-out.pl \
    --rpt_output rpt_iccad2014/${benchmark}${suffix}.html \
    ${options} \
    "

echo "bin/MrDP $commands"
# run placement 
time ("bin/MrDP" $commands) > rpt_iccad2014/${benchmark}${suffix}.rpt 2>&1

echo "run evaluation and append to rpt_iccad2014/${benchmark}${suffix}.rpt"
# run evaluation and append to .rpt 
./lib/iccad2013_check_legality/iccad2013_check_legality \
    ${benchmarks_dir}/${benchmark}/bookshelf/${benchmark}${mrsuffix}.aux \
    ${solution_dir}/${benchmark}-out.pl \
    >> rpt_iccad2014/${benchmark}${suffix}.rpt

./lib/iccad2013_evaluate_solution/iccad2013_evaluate_solution \
    ${benchmarks_dir}/${benchmark}/bookshelf/${benchmark}${mrsuffix}.aux \
    ${solution_dir}/${benchmark}-out.pl \
    ${util_map[iccad2014-$benchmark]} \
    >> rpt_iccad2014/${benchmark}${suffix}.rpt
	
done
